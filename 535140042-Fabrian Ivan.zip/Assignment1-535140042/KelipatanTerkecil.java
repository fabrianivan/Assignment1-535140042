
public class KelipatanTerkecil extends Assignment {

	public int getResult() throws Exception {
		// Buatlah kode program jawaban kalian di dalam method ini
		
		int b = 0;
		int c = 0;
		
		while (c != 20){
			c = 0;
			b++;
			for(int i = 1; i <= 20; i++){
				if (b % i == 0){
					c = c + 1;
				}
			} 
		}
		
		// Pastikan hasil dari perhitungan anda di-return pada baris kode di bawah ini
		return b;
	}
	
}

