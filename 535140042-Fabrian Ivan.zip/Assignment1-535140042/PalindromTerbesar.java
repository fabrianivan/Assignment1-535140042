public class PalindromTerbesar extends Assignment {
	public int getResult() throws Exception {
		// Buatlah kode program jawaban kalian di dalam method ini
		
		int[] a = new int[1000000];
		int b = 0;
		int num;
		int rmd;
		int n;
		int max = 0;
		
		for(int i = 100; i <= 999; i++){
			for(int j = 100; j <= 999; j++){
				a[b] = i*j;
				b++;
			}
		}
		
		for(int i = 0; i < b; i++){
			int rev = 0;
			num = a[i];
			n = num;
			
			while(num != 0){
				rmd = num % 10;
				rev = (rev*10) + rmd;
				num = num / 10;
			}
			
			if(rev == n){
				if(n > max){
					max = n;
				}
			}
			
		}
		// Pastikan hasil dari perhitungan anda di-return pada baris kode di bawah ini
		return max ;
	}
}