public class JumlahPrima extends Assignment {

	public int getResult() throws Exception {
		// Buatlah kode program jawaban kalian di dalam method ini
		int n = 100000;
		int count = 0;
        for (int i = 2; i < n; i++) {
            boolean isPrima = true;
            for (int j = 2; j < i; j++) {
                if (i % j == 0) {
                    isPrima = false;
                    break;
                }
            }
            if (isPrima) {
                count=count+i;
            }
        }
		// Pastikan hasil dari perhitungan anda di-return pada baris kode di bawah ini
		return count;
	}
	
}
