public class AngkaSahabat extends Assignment {

	public int getResult() throws Exception {
		// Buatlah kode program jawaban kalian di dalam method ini
		
		int a;
		int b;
		int hasil;
		
		hasil = 0;
		
		for(int i=1; i<=10000; i++)
		{
			a=0;
			b=0;
			for(int j=1; j<i; j++)
			{
				if(i%j==0)
				{
					a=a+j;
				}
			}
			for(int k=1; k<a; k++)
			{
				if(a%k==0)
				{
					b=b+k;
				}
			}
			if(b==i && a!=i)
			{
				hasil=hasil+a+b;
			}
		}
		hasil=hasil/2;
		// Pastikan hasil dari perhitungan anda di-return pada baris kode di bawah ini
		
		return hasil;
	}
}