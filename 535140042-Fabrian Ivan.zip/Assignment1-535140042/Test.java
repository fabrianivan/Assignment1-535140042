public class Test {
	public static void main(String[] args) throws Exception {	
		Assignment a;
		Checker c = new Checker();
		
		a = new JumlahPrima();
		a.test();
		c.check(a);
		
		a = new KelipatanTerkecil();
		a.test();
		c.check(a);
		
		a = new AngkaSahabat();
		a.test();
		c.check(a);
		
		a = new PalindromTerbesar();
		a.test();
		c.check(a);
		
		System.out.println("Score = " + c.getScore());
	}
}
