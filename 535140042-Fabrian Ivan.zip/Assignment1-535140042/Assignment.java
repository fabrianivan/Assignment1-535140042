public abstract class Assignment {
	// Isikan dengan NIM anda
	public static final String NIM = "535140042";
	
	// Isikan dengan NAMA anda
	public static final String NAMA = "Fabrian Ivan Prasetya";
	
	// Isikan dengan kode kelas anda (A = Jumat, B = Senin)
	public static final String KELAS = "B";
	
	
	/*
	 * Jangan ubah method-method yang berada di bawah komentar ini
	 */
	public abstract int getResult() throws Exception;
	public void test() throws Exception {
		System.out.print("Running " + this.getClass().getName() + " returns " + this.getResult());
	}
}
